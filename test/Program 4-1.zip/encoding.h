#ifndef ENCODING_H
#define ENCODING_H

#define CHAR_LEN 27

static char char_list[] = "ABCDEFGHIJKLMNOPQRSTUVWXYZ ";

#endif
